AJ BET demo website

Files:
- index.html: responsive website and mini-games
- assets/aj-bet-logo.png: AJ BET logo

This is a static demo. Coins are virtual, saved locally in the visitor's browser, and have no cash value. It does not include user accounts, server-side storage, deposits, withdrawals, betting, or cash prizes.

To publish:
1. Create a public GitHub repository named aj-bet.
2. Upload index.html and the assets folder (keep the same folder structure).
3. Open repository Settings > Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for GitHub Pages to publish the site.
